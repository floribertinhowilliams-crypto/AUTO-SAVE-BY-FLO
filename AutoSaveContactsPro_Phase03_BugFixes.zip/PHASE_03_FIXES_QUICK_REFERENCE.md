# Phase 03 Bug Fixes - Quick Reference

## 🎯 3 Issues + 3 Fixes

### Issue 1️⃣: "Detects but Doesn't Save"
**Fix:** Add retry logic to phonebook saving

**Before:**
```kotlin
val success = contactManager.saveContactToPhonebook(phoneNumber, displayName)
if (!success) {
    Log.w(TAG, "Failed to save")  // Give up immediately ❌
}
```

**After:**
```kotlin
val success = saveToPhonebookWithRetry(phoneNumber, displayName, maxRetries = 3)
// Tries 3 times automatically ✅
```

---

### Issue 2️⃣: "Saves Group Chat Numbers"
**Fix:** Filter out group chats

**Before:**
```kotlin
val senderName = "Family Group"
val phoneNumber = parsePhoneNumber(senderName)  // Tries to parse! ❌
```

**After:**
```kotlin
val senderName = "Family Group"
if (isGroupChat(senderName)) {
    return null  // Skip! ✅
}
val phoneNumber = parsePhoneNumber(senderName)
```

---

### Issue 3️⃣: "Doesn't Save Upcoming Contacts"
**Fix:** Better error handling + explicit status update

**Before:**
```kotlin
val contactId = repository.saveDetectedContact(contact)
// If this fails, what happens? No clear status ❌
```

**After:**
```kotlin
try {
    val contactId = repository.saveDetectedContact(contact)
    if (contactId <= 0) {
        Log.e(TAG, "Invalid ID returned")
        return  // Stop, mark as FAILED
    }
} catch (e: Exception) {
    Log.e(TAG, "Save failed: ${e.message}")
    return  // Stop, mark as FAILED
}
```

---

## 📋 3 Files to Update

### 1. WhatsAppNotificationParser.kt
**Add this function:**
```kotlin
private fun isGroupChat(senderName: String?): Boolean {
    if (senderName == null) return false
    val lower = senderName.lowercase()
    
    // Check for group keywords
    if (lower.contains("group") || 
        lower.contains("family") || 
        lower.contains("team") || 
        lower.contains("chat") ||
        lower.contains("gc") ||
        lower.contains("grp")) {
        return true
    }
    
    // Check for multiple names
    if (senderName.count { it == ',' } >= 2) {
        return true
    }
    
    return false
}
```

**Use it here:**
```kotlin
private fun extractContactFromNotification(...): DetectedContact? {
    val senderName = extractSenderName(notification)
    
    // ADD THIS CHECK:
    if (isGroupChat(senderName)) {
        Log.d(TAG, "✗ Skipping group chat: $senderName")
        return null
    }
    
    // Rest of code...
}
```

---

### 2. AutoSaveNotificationListenerService.kt
**Add this function:**
```kotlin
private suspend fun saveToPhonebookWithRetry(
    phoneNumber: String,
    displayName: String?,
    maxRetries: Int = 3
): Boolean {
    var lastError: Exception? = null
    
    for (attempt in 1..maxRetries) {
        try {
            Log.d(TAG, "Saving (attempt $attempt/$maxRetries): $phoneNumber")
            val success = contactManager.saveContactToPhonebook(
                phoneNumber = phoneNumber,
                displayName = displayName
            )
            
            if (success) {
                Log.i(TAG, "✓ Saved on attempt $attempt")
                return true
            }
        } catch (e: Exception) {
            Log.w(TAG, "✗ Failed attempt $attempt: ${e.message}")
            lastError = e
            
            // Don't retry permission errors
            if (e.message?.contains("permission", ignoreCase = true) == true) {
                return false
            }
        }
        
        // Wait before retry (exponential backoff)
        if (attempt < maxRetries) {
            val delayMs = (100 * attempt).toLong()
            delay(delayMs)
        }
    }
    
    Log.e(TAG, "✗ All attempts failed")
    return false
}
```

**Update this part:**
```kotlin
private suspend fun processNotification(sbn: StatusBarNotification) {
    // ... earlier code ...
    
    // CHANGE THIS:
    val phoneBookSuccess = contactManager.saveContactToPhonebook(...)
    
    // TO THIS:
    val phoneBookSuccess = saveToPhonebookWithRetry(
        phoneNumber = detectedContact.phoneNumber,
        displayName = detectedContact.senderName,
        maxRetries = 3
    )
    
    // ... rest of code ...
}
```

---

### 3. Better Error Handling (Add to processNotification)

```kotlin
private suspend fun processNotification(sbn: StatusBarNotification) {
    // Parse notification
    val detectedContact = WhatsAppNotificationParser.parseNotification(sbn)
    if (detectedContact == null) {
        Log.d(TAG, "Could not parse contact (possibly group chat)")
        return
    }
    
    Log.d(TAG, "✓ Detected: ${detectedContact.phoneNumber}")
    
    // Check if already recorded
    val isAlreadyRecorded = try {
        repository.isAlreadyRecorded(detectedContact.phoneNumber)
    } catch (e: Exception) {
        Log.e(TAG, "✗ Error checking if recorded: ${e.message}")
        false
    }
    
    if (isAlreadyRecorded) {
        Log.d(TAG, "ℹ Already recorded")
        return
    }
    
    // Save to database
    val contactId = try {
        repository.saveDetectedContact(detectedContact)
    } catch (e: Exception) {
        Log.e(TAG, "✗ Failed to save to DB: ${e.message}")
        return
    }
    
    if (contactId <= 0) {
        Log.e(TAG, "✗ Invalid ID returned: $contactId")
        return
    }
    
    Log.d(TAG, "💾 Saved to DB (ID: $contactId)")
    
    // Save to phonebook WITH RETRY
    val phoneBookSuccess = saveToPhonebookWithRetry(
        phoneNumber = detectedContact.phoneNumber,
        displayName = detectedContact.senderName,
        maxRetries = 3
    )
    
    // Update status
    val finalStatus = if (phoneBookSuccess) 
        DetectionStatus.SAVED 
    else 
        DetectionStatus.FAILED
    
    try {
        repository.updateContactStatus(
            detectedContact.copy(id = contactId, status = finalStatus)
        )
    } catch (e: Exception) {
        Log.e(TAG, "✗ Failed to update status: ${e.message}")
    }
    
    if (phoneBookSuccess) {
        Log.i(TAG, "✅ SUCCESS: Contact saved!")
    } else {
        Log.w(TAG, "⚠ DB saved but phonebook failed (marked FAILED)")
    }
}
```

---

## 🎯 Implementation Checklist

- [ ] Add `isGroupChat()` function to WhatsAppNotificationParser
- [ ] Add group chat check in `extractContactFromNotification()`
- [ ] Add `saveToPhonebookWithRetry()` function to NotificationListenerService
- [ ] Replace direct save with retry logic in `processNotification()`
- [ ] Add try-catch for database operations
- [ ] Build and test
- [ ] Verify logs show proper flow

---

## ✅ Verification Logs

After applying fixes, you should see:

```
✓ Notification Listener connected
📲 Notification from com.whatsapp
✓ Detected contact: +255712345678 (John)
💾 Saved to database (ID: 123)
Saving to phonebook (attempt 1/3): +255712345678
✓ Phonebook save succeeded on attempt 1
✅ SUCCESS: Contact saved to phonebook and database!
```

Or for group chats:
```
✓ Detected contact: Family Group
✗ Skipping group chat: Family Group
```

Or with retry:
```
Saving to phonebook (attempt 1/3): +255712345678
✗ Failed attempt 1: Connection timeout
Saving to phonebook (attempt 2/3): +255712345678
✓ Phonebook save succeeded on attempt 2
✅ SUCCESS: Contact saved!
```

---

## 🚀 Time to Apply

- **Copy & Paste:** ~5 minutes
- **Test:** ~10 minutes
- **Total:** ~15 minutes

---

## ⚠️ If Something Goes Wrong

1. **Rollback:** Use your `.bak` file backups
2. **Check logs:** `adb logcat | grep AutoSave`
3. **Verify:** Permissions granted in settings
4. **Debug:** Add more `Log.d()` statements

---

**Apply these fixes and your AutoSave app will be rock solid!** 🔥
