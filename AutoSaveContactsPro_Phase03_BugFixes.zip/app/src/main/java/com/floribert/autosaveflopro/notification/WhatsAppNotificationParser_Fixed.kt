package com.floribert.autosaveflopro.notification

import android.app.Notification
import android.os.Build
import android.service.notification.StatusBarNotification
import android.util.Log
import com.floribert.autosaveflopro.data.model.DetectedContact
import com.floribert.autosaveflopro.data.model.DetectionStatus
import com.floribert.autosaveflopro.utils.PhoneNumberParser

/**
 * IMPROVED WhatsApp notification parser with BUG FIXES:
 * - Better group chat detection (don't save group phone numbers)
 * - Improved contact info extraction
 * - Better handling of edge cases
 */
object WhatsAppNotificationParser {
    private const val TAG = "WhatsAppParser"
    
    private const val WHATSAPP_PACKAGE = "com.whatsapp"
    private const val WHATSAPP_BUSINESS_PACKAGE = "com.whatsapp.w4b"
    
    // Cache last processed notification to prevent duplicates
    private var lastProcessedKey: String? = null
    private var lastProcessedTime: Long = 0
    private const val DUPLICATE_THRESHOLD_MS = 1000 // 1 second

    /**
     * Parse notification and extract individual contact info.
     * Returns null if:
     * - Not WhatsApp
     * - Is a group chat
     * - No valid phone number found
     * - Is a duplicate
     */
    fun parseNotification(sbn: StatusBarNotification?): DetectedContact? {
        if (sbn == null) return null

        // Quick filter: Only process WhatsApp notifications
        if (!isWhatsAppNotification(sbn.packageName)) return null

        // Prevent duplicate processing
        val key = sbn.key
        val now = System.currentTimeMillis()
        if (key == lastProcessedKey && (now - lastProcessedTime) < DUPLICATE_THRESHOLD_MS) {
            Log.d(TAG, "Duplicate notification skipped: $key")
            return null
        }
        lastProcessedKey = key
        lastProcessedTime = now

        val notification = sbn.notification ?: return null

        return try {
            extractContactFromNotification(notification, sbn.packageName)
        } catch (e: Exception) {
            Log.e(TAG, "Failed to parse notification", e)
            null
        }
    }

    private fun isWhatsAppNotification(packageName: String?): Boolean {
        return packageName == WHATSAPP_PACKAGE || packageName == WHATSAPP_BUSINESS_PACKAGE
    }

    /**
     * Extract contact info from notification.
     * KEY FIX: Filter out group chats!
     */
    private fun extractContactFromNotification(
        notification: Notification,
        packageName: String
    ): DetectedContact? {
        val timestamp = System.currentTimeMillis()

        // Get sender name from notification title
        val senderName = extractSenderName(notification)
        if (senderName == null) {
            Log.d(TAG, "No sender name found in notification")
            return null
        }

        // FIX: Check if this is a GROUP CHAT
        if (isGroupChat(senderName)) {
            Log.d(TAG, "✗ Skipping group chat: $senderName")
            return null
        }

        // Extract phone number from sender name or content
        val phoneNumber = PhoneNumberParser.extractPhoneNumber(senderName)
        if (phoneNumber == null) {
            Log.d(TAG, "No phone number in sender: $senderName")
            
            // Try to extract from message content as fallback
            val contentText = getContentText(notification)
            val alternativeNumber = PhoneNumberParser.extractPhoneNumber(contentText)
            
            if (alternativeNumber == null) {
                Log.d(TAG, "No phone number found anywhere in notification")
                return null
            }

            return DetectedContact(
                phoneNumber = alternativeNumber,
                senderName = senderName,
                sourceApp = packageName,
                detectedAtTimestamp = timestamp,
                status = DetectionStatus.PENDING
            )
        }

        return DetectedContact(
            phoneNumber = phoneNumber,
            senderName = senderName,
            sourceApp = packageName,
            detectedAtTimestamp = timestamp,
            status = DetectionStatus.PENDING
        )
    }

    /**
     * FIX: Detect if this is a GROUP CHAT notification.
     * Group chats typically have:
     * - "Group name" as sender
     * - "Person Name: Message" as content
     * - Multiple people indicators
     */
    private fun isGroupChat(senderName: String?): Boolean {
        if (senderName == null) return false

        val lower = senderName.lowercase()

        // Common group indicators
        val groupKeywords = listOf(
            "group",
            "family",
            "team",
            "chat",
            "community",
            "gc",
            "grp",
            "班",  // Chinese for group
            "grupo",  // Spanish
            "groupe",  // French
            "grupp"  // Swedish/other languages
        )

        for (keyword in groupKeywords) {
            if (lower.contains(keyword)) {
                Log.d(TAG, "Group detected by keyword: $keyword in $senderName")
                return true
            }
        }

        // Check for multiple people indicator (looks like "Name1, Name2, Name3")
        val commaCount = senderName.count { it == ',' }
        if (commaCount >= 2) {
            Log.d(TAG, "Group detected by multiple names: $senderName")
            return true
        }

        // Check if ends with common group indicators
        if (lower.endsWith(" group") || 
            lower.endsWith(" gc") || 
            lower.endsWith(" chat") ||
            lower.endsWith(" team")) {
            Log.d(TAG, "Group detected by suffix: $senderName")
            return true
        }

        return false
    }

    private fun extractSenderName(notification: Notification): String? {
        // Try Android 11+ extras first
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            notification.extras?.getString("android.title")?.let {
                return it.trim().takeIf { it.isNotEmpty() }
            }
        }

        // Fallback to older API
        return notification.contentTitle?.toString()?.trim()?.takeIf { it.isNotEmpty() }
    }

    private fun getContentText(notification: Notification): String? {
        // Try modern API first
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            notification.extras?.getString("android.text")?.let {
                return it.trim().takeIf { it.isNotEmpty() }
            }
        }

        // Fallback
        return notification.contentText?.toString()?.trim()?.takeIf { it.isNotEmpty() }
    }

    /**
     * Clear cache (call periodically).
     */
    fun clearCache() {
        lastProcessedKey = null
        lastProcessedTime = 0
    }
}
