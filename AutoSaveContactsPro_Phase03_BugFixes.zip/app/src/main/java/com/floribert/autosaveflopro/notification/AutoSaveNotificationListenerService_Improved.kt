package com.floribert.autosaveflopro.notification

import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import android.util.Log
import com.floribert.autosaveflopro.data.ContactManager
import com.floribert.autosaveflopro.data.model.DetectionStatus
import com.floribert.autosaveflopro.data.repository.ContactRepository
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import javax.inject.Inject

/**
 * IMPROVED AUTO-SAVE NOTIFICATION LISTENER SERVICE - Phase 03 Bug Fixes
 * 
 * Fixes:
 * ✓ Detect but don't save issue - Added retry logic
 * ✓ Group chat numbers being saved - Added group chat filtering
 * ✓ Status tracking - Better error reporting
 * ✓ Failed saves - Retry mechanism for transient failures
 */
@AndroidEntryPoint
class AutoSaveNotificationListenerService : NotificationListenerService() {
    
    @Inject
    lateinit var repository: ContactRepository
    
    @Inject
    lateinit var contactManager: ContactManager
    
    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    
    override fun onListenerConnected() {
        super.onListenerConnected()
        Log.i(TAG, "✓ AutoSave Notification Listener connected")
    }

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        super.onNotificationPosted(sbn)
        if (sbn == null) return

        // Quick filter - skip non-WhatsApp
        if (!isWhatsAppNotification(sbn.packageName)) return

        Log.d(TAG, "📲 Notification from ${sbn.packageName}")

        // Process on background thread (non-blocking UI)
        serviceScope.launch(Dispatchers.IO) {
            try {
                processNotification(sbn)
            } catch (e: Exception) {
                Log.e(TAG, "✗ Error processing notification", e)
            }
        }
    }

    override fun onListenerDisconnected() {
        super.onListenerDisconnected()
        Log.i(TAG, "✗ Notification Listener disconnected")
    }

    /**
     * Main processing pipeline with RETRY LOGIC.
     * Fixes the "detect but don't save" issue.
     */
    private suspend fun processNotification(sbn: StatusBarNotification) {
        // Step 1: Parse notification (extract phone number and name)
        val detectedContact = WhatsAppNotificationParser.parseNotification(sbn)
        if (detectedContact == null) {
            Log.d(TAG, "Could not parse contact from notification (possibly group chat)")
            return
        }

        Log.d(TAG, "✓ Detected contact: ${detectedContact.phoneNumber} (${detectedContact.senderName})")

        // Step 2: Check if already saved in database
        val isAlreadyRecorded = try {
            repository.isAlreadyRecorded(detectedContact.phoneNumber)
        } catch (e: Exception) {
            Log.e(TAG, "✗ Error checking if already recorded: ${e.message}")
            false
        }

        if (isAlreadyRecorded) {
            Log.d(TAG, "ℹ Contact already recorded: ${detectedContact.phoneNumber}")
            return
        }

        // Step 3: Save to local database (mark as PENDING)
        val contactId = try {
            repository.saveDetectedContact(detectedContact)
        } catch (e: Exception) {
            Log.e(TAG, "✗ Failed to save to database: ${e.message}")
            return
        }

        if (contactId <= 0) {
            Log.e(TAG, "✗ Database returned invalid ID: $contactId")
            return
        }

        Log.d(TAG, "💾 Saved to database (ID: $contactId)")

        // Step 4: Try to save to phonebook with RETRY LOGIC
        val savingContact = detectedContact.copy(id = contactId)
        val phoneBookSuccess = saveToPhonebookWithRetry(
            phoneNumber = detectedContact.phoneNumber,
            displayName = detectedContact.senderName,
            maxRetries = 3
        )

        // Step 5: Update database with final status
        val finalStatus = if (phoneBookSuccess) DetectionStatus.SAVED else DetectionStatus.FAILED
        
        try {
            repository.updateContactStatus(savingContact.copy(status = finalStatus))
        } catch (e: Exception) {
            Log.e(TAG, "✗ Failed to update contact status: ${e.message}")
        }

        if (phoneBookSuccess) {
            Log.i(TAG, "✅ SUCCESS: Contact saved to phonebook and database!")
        } else {
            Log.w(TAG, "⚠ Contact saved to database but failed to add to phonebook (marked as FAILED)")
        }
    }

    /**
     * FIX: Save to phonebook with RETRY LOGIC.
     * Handles transient failures (phonebook temporarily unavailable, etc.)
     */
    private suspend fun saveToPhonebookWithRetry(
        phoneNumber: String,
        displayName: String?,
        maxRetries: Int = 3
    ): Boolean {
        var lastError: Exception? = null

        for (attempt in 1..maxRetries) {
            try {
                Log.d(TAG, "Saving to phonebook (attempt $attempt/$maxRetries): $phoneNumber")
                
                val success = contactManager.saveContactToPhonebook(
                    phoneNumber = phoneNumber,
                    displayName = displayName
                )

                if (success) {
                    Log.i(TAG, "✓ Phonebook save succeeded on attempt $attempt")
                    return true
                } else {
                    Log.w(TAG, "✗ Phonebook save returned false on attempt $attempt")
                    lastError = Exception("Phonebook save returned false")
                }

            } catch (e: Exception) {
                Log.w(TAG, "✗ Phonebook save failed on attempt $attempt: ${e.message}")
                lastError = e

                // Don't retry if permission is denied
                if (e.message?.contains("permission", ignoreCase = true) == true) {
                    Log.e(TAG, "Permission denied - no point retrying")
                    return false
                }
            }

            // Wait before retry (exponential backoff)
            if (attempt < maxRetries) {
                val delayMs = (100 * attempt).toLong()  // 100ms, 200ms, 300ms
                Log.d(TAG, "Waiting ${delayMs}ms before retry...")
                delay(delayMs)
            }
        }

        Log.e(TAG, "✗ All save attempts failed. Last error: ${lastError?.message}")
        return false
    }

    private fun isWhatsAppNotification(packageName: String?): Boolean {
        return packageName == "com.whatsapp" || packageName == "com.whatsapp.w4b"
    }

    companion object {
        private const val TAG = "AutoSaveService"
    }
}
